# Pinwheel — Metavinci Integration Plan

## Overview

Integrate `hvym-pinwheel` (deployed via PyPI, branded **Pinwheel**) into the Metavinci system tray application as a managed background service. The Pinwheel daemon runs alongside the Pintheon gateway, sharing the same Kubo node and Stellar wallet. Metavinci's tray menu gains a "Pinwheel" submenu with start/stop, mode toggle, status, and earnings display.

---

## Architecture

```
Metavinci (PyQt5 tray app)
├── Pintheon Gateway (Docker)      ← already integrated
│   └── Kubo daemon @ localhost:5001
├── Pinwheel (QThread worker)      ← NEW
│   ├── PinnerDaemon async loop
│   ├── SQLite state @ pintheon_data/pinner.db
│   └── Data API (in-process, no HTTP)
├── Metadata API (FastAPI :7777)
├── Tunnel Client (WebSocket)
└── Wallet Manager (TinyDB)
```

Pinwheel runs **in-process** as a QThread — no subprocess, no separate HTTP server. Metavinci calls the `DataAggregator` directly for dashboard data. This mirrors the `ApiServerWorker` pattern already used for the Metadata API.

---

## Prerequisites

```
pip install hvym-pinwheel
```

The package pulls in: `stellar-sdk[aiohttp]`, `httpx`, `aiosqlite`, `click`.

Metavinci already has `stellar-sdk` and `httpx` in its dependency tree, so the incremental cost is `aiosqlite` only.

---

## Phase 1: PinwheelWorker (QThread)

### New file: `pinwheel_worker.py`

A QThread wrapper around `PinnerDaemon` that manages its own asyncio event loop — identical pattern to `api_server.py:ApiServerWorker`.

```python
"""
Pinwheel Daemon Worker

QThread wrapper that runs the PinnerDaemon async loop in a background thread.
Follows the same pattern as ApiServerWorker (api_server.py).
"""

import asyncio
import logging
from typing import Optional

try:
    from hvym_pinner.daemon import PinnerDaemon
    from hvym_pinner.config import load_config
    from hvym_pinner.models.config import DaemonConfig, DaemonMode
    from hvym_pinner.models.snapshots import DashboardSnapshot
    PINNER_AVAILABLE = True
except ImportError:
    PINNER_AVAILABLE = False
    PinnerDaemon = None
    DaemonConfig = None
    DaemonMode = None

try:
    from PyQt5.QtCore import QThread, pyqtSignal
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False
    QThread = object
    pyqtSignal = lambda *args: None


class PinwheelWorker(QThread):
    """
    QThread worker that runs the Pinwheel (PinnerDaemon) async loop.

    Signals:
        started_signal: Emitted when Pinwheel starts successfully
        stopped_signal: Emitted when Pinwheel stops
        error_signal: Emitted with error message on failure
        status_signal: Emitted with status string on state changes
    """

    if PYQT5_AVAILABLE:
        started_signal = pyqtSignal()
        stopped_signal = pyqtSignal()
        error_signal = pyqtSignal(str)
        status_signal = pyqtSignal(str)

    def __init__(self, config: 'DaemonConfig', parent=None):
        if PYQT5_AVAILABLE:
            super().__init__(parent)
        else:
            super().__init__()
        self.config = config
        self.daemon: Optional['PinnerDaemon'] = None
        self._running = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def data_api(self):
        """Direct access to the daemon's DataAggregator (thread-safe reads)."""
        if self.daemon:
            return self.daemon.data_api
        return None

    def run(self):
        """Main thread execution — starts the PinnerDaemon async loop."""
        if not PINNER_AVAILABLE:
            self._emit_error("hvym-pinwheel not installed")
            return

        try:
            self.daemon = PinnerDaemon(self.config)
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)

            self._running = True
            self._emit_started()
            logging.info("Pinwheel daemon starting")

            self._loop.run_until_complete(self.daemon.start())

        except Exception as e:
            self._emit_error(f"Pinner daemon error: {e}")
        finally:
            self._running = False
            if self._loop:
                self._loop.close()
            self.daemon = None
            self._emit_stopped()
            logging.info("Pinwheel daemon stopped")

    def stop(self):
        """Request graceful daemon shutdown."""
        if self.daemon and self._running and self._loop:
            asyncio.run_coroutine_threadsafe(self.daemon.stop(), self._loop)
            logging.info("Pinwheel daemon shutdown requested")

    def get_dashboard_sync(self) -> Optional[dict]:
        """Fetch dashboard snapshot from the Pinwheel thread (blocking).

        Call from the main Qt thread to get current status.
        Returns dict or None if Pinwheel isn't running.
        """
        if not self.daemon or not self._loop or not self._running:
            return None
        try:
            future = asyncio.run_coroutine_threadsafe(
                self.daemon.data_api.get_dashboard(), self._loop
            )
            snapshot = future.result(timeout=5)
            return snapshot.to_dict()
        except Exception as e:
            logging.warning(f"Failed to get Pinwheel dashboard: {e}")
            return None

    # Signal helpers (same pattern as ApiServerWorker)
    def _emit_started(self):
        if PYQT5_AVAILABLE and hasattr(self, 'started_signal'):
            self.started_signal.emit()

    def _emit_stopped(self):
        if PYQT5_AVAILABLE and hasattr(self, 'stopped_signal'):
            self.stopped_signal.emit()

    def _emit_error(self, msg: str):
        if PYQT5_AVAILABLE and hasattr(self, 'error_signal'):
            self.error_signal.emit(msg)

    def _emit_status(self, msg: str):
        if PYQT5_AVAILABLE and hasattr(self, 'status_signal'):
            self.status_signal.emit(msg)
```

### Key design decisions

| Decision | Rationale |
|----------|-----------|
| In-process QThread | Matches `ApiServerWorker` pattern. No subprocess management, no IPC overhead, direct `DataAggregator` access. |
| Own asyncio event loop | Pinwheel is fully async. The QThread gets its own loop, same as the API server thread. |
| `get_dashboard_sync()` | Cross-thread bridge: main Qt thread calls this to read Pinwheel state. Uses `run_coroutine_threadsafe` with a 5s timeout. |
| `DaemonConfig` passed in | Metavinci builds the config from its own state (wallet keypair, network, Kubo URL, DB path) rather than reading a TOML file. |

---

## Phase 2: Configuration Bridge

Metavinci already knows everything the pinner needs:

| Pinner Config Field | Metavinci Source |
|---------------------|------------------|
| `keypair_secret` | `WalletManager` — active wallet's secret key |
| `contract_id` | `DeploymentManager` or hardcoded per network |
| `factory_contract_id` | Same as above |
| `rpc_url` | Network-dependent (`soroban-testnet.stellar.org` / mainnet) |
| `network_passphrase` | Derived from `PINTHEON_NETWORK` |
| `kubo_rpc_url` | `http://127.0.0.1:5001` (Pintheon's Kubo) |
| `db_path` | `~/pintheon_data/pinner.db` (alongside Pintheon volume) |
| `mode` | User choice: auto/approve (stored in TinyDB `app_data`) |
| `min_price` | User-configurable in XLM (stored as stroops in TinyDB) |

### Config builder function

```python
def build_pinner_config(
    keypair_secret: str,
    network: str = "testnet",
    contract_id: str = "",
    factory_contract_id: str = "",
    mode: str = "auto",
    min_price: int = 10_000_000,  # stroops (1 XLM)
    db_path: str = "",
    hunter_enabled: bool = False,
) -> 'DaemonConfig':
    """Build a DaemonConfig from Metavinci's current state."""
    from hvym_pinner.models.config import DaemonConfig, DaemonMode, HunterConfig

    rpc_urls = {
        "testnet": "https://soroban-testnet.stellar.org",
        "mainnet": "https://soroban.stellar.org",
    }
    passphrases = {
        "testnet": "Test SDF Network ; September 2015",
        "mainnet": "Public Global Stellar Network ; September 2015",
    }

    if not db_path:
        from pathlib import Path
        db_path = str(Path.home() / "pintheon_data" / "pinner.db")

    return DaemonConfig(
        mode=DaemonMode(mode),
        rpc_url=rpc_urls.get(network, rpc_urls["testnet"]),
        network_passphrase=passphrases.get(network, passphrases["testnet"]),
        network=network,
        contract_id=contract_id,
        factory_contract_id=factory_contract_id,
        keypair_secret=keypair_secret,
        kubo_rpc_url="http://127.0.0.1:5001",
        db_path=db_path,
        min_price=min_price,
        hunter=HunterConfig(enabled=hunter_enabled),
    )
```

### Wallet selection

Pinwheel needs a Stellar secret key. Metavinci's `WalletManager` stores wallets in `wallets.json`. The integration should:

1. On first pinner start, show a wallet selection dialog (list wallets for current network)
2. Store the selected wallet address in TinyDB: `{'pinwheel_wallet': 'GABCD...'}`
3. On subsequent starts, use the stored wallet
4. Provide a "Change Pinwheel Wallet" action in the Settings submenu

For **testnet** wallets, the secret is stored plaintext. For **mainnet**, it's Fernet-encrypted — the user must enter their password to decrypt before the daemon can start.

---

## Phase 3: Metavinci Integration (metavinci.py)

### 3a. Import block (top of metavinci.py)

Add alongside the existing optional imports:

```python
# Try to import Pinwheel daemon
try:
    from pinwheel_worker import PinwheelWorker, PINNER_AVAILABLE, build_pinner_config
    HAS_PINWHEEL = PINNER_AVAILABLE
except ImportError:
    HAS_PINWHEEL = False
    PinwheelWorker = None
```

### 3b. Instance variables (in `__init__`)

Add after `self.API_ACTIVE = False`:

```python
# Pinwheel daemon
self.pinwheel_worker = None
self.PINWHEEL_ACTIVE = False
self.PINWHEEL_MODE = self._get_pinwheel_mode()  # 'auto' or 'approve'
self.PINWHEEL_WALLET = self._get_pinwheel_wallet()  # stored address or None
```

### 3c. Tray menu — Pinwheel submenu

Create `_setup_pinwheel_menu(tray_menu)` method. Insert into the menu between the Metadata API and Wallet Management sections:

```python
def _setup_pinwheel_menu(self, tray_menu):
    """Set up the Pinwheel submenu in the system tray."""
    self.tray_pinwheel_menu = tray_menu.addMenu("Pinwheel")
    self.tray_pinwheel_menu.setIcon(self.pinwheel_icon)

    # Status line (disabled, informational)
    self.pinwheel_status_action = QAction("Status: Stopped", self)
    self.pinwheel_status_action.setEnabled(False)
    self.tray_pinwheel_menu.addAction(self.pinwheel_status_action)

    self.tray_pinwheel_menu.addSeparator()

    # Start / Stop
    self.start_pinwheel_action = QAction(self.pinwheel_icon, "Start Pinwheel", self)
    self.start_pinwheel_action.triggered.connect(self._start_pinwheel)

    self.stop_pinwheel_action = QAction(self.pinwheel_icon, "Stop Pinwheel", self)
    self.stop_pinwheel_action.triggered.connect(self._stop_pinwheel)
    self.stop_pinwheel_action.setVisible(False)

    self.tray_pinwheel_menu.addAction(self.start_pinwheel_action)
    self.tray_pinwheel_menu.addAction(self.stop_pinwheel_action)

    self.tray_pinwheel_menu.addSeparator()

    # Mode toggle
    self.pinwheel_mode_action = QAction(self.cog_icon, f"Mode: {self.PINWHEEL_MODE}", self)
    self.pinwheel_mode_action.triggered.connect(self._toggle_pinwheel_mode)
    self.tray_pinwheel_menu.addAction(self.pinwheel_mode_action)

    # Settings submenu
    self.pinwheel_settings_menu = self.tray_pinwheel_menu.addMenu("Settings")
    self.pinwheel_settings_menu.setIcon(self.cog_icon)

    self.pinwheel_wallet_action = QAction(self.stellar_icon, "Select Wallet...", self)
    self.pinwheel_wallet_action.triggered.connect(self._select_pinwheel_wallet)
    self.pinwheel_settings_menu.addAction(self.pinwheel_wallet_action)

    self.pinwheel_min_price_action = QAction(self.cog_icon, "Set Min Price...", self)
    self.pinwheel_min_price_action.triggered.connect(self._set_pinwheel_min_price)
    self.pinwheel_settings_menu.addAction(self.pinwheel_min_price_action)

    # Info submenu (visible when running)
    self.pinwheel_info_menu = self.tray_pinwheel_menu.addMenu("Dashboard")
    self.pinwheel_info_menu.setIcon(self.web_icon)
    self.pinwheel_info_menu.setEnabled(False)

    self.pinwheel_earnings_action = QAction("Earnings: --", self)
    self.pinwheel_earnings_action.setEnabled(False)
    self.pinwheel_info_menu.addAction(self.pinwheel_earnings_action)

    self.pinwheel_pins_action = QAction("Pins: --", self)
    self.pinwheel_pins_action.setEnabled(False)
    self.pinwheel_info_menu.addAction(self.pinwheel_pins_action)

    self.pinwheel_offers_action = QAction("Offers: --", self)
    self.pinwheel_offers_action.setEnabled(False)
    self.pinwheel_info_menu.addAction(self.pinwheel_offers_action)
```

Insert into the tray menu build sequence (around line 1781):

```python
# Add Pinwheel menu if available
if HAS_PINWHEEL:
    self._setup_pinwheel_menu(tray_menu)
```

### 3d. Service lifecycle methods

```python
# =========================================================================
# Pinwheel Methods
# =========================================================================

def _get_pinwheel_mode(self) -> str:
    """Get Pinwheel mode from TinyDB config."""
    try:
        result = self.DB.search(self.QUERY.type == 'app_data')
        if result and 'pinwheel_mode' in result[0]:
            return result[0]['pinwheel_mode']
    except Exception:
        pass
    return 'auto'

def _get_pinwheel_wallet(self) -> str:
    """Get stored Pinwheel wallet address from TinyDB."""
    try:
        result = self.DB.search(self.QUERY.type == 'app_data')
        if result and 'pinwheel_wallet' in result[0]:
            return result[0]['pinwheel_wallet']
    except Exception:
        pass
    return ''

def _get_pinwheel_min_price(self) -> int:
    """Get Pinwheel minimum price from TinyDB config (stored as stroops)."""
    try:
        result = self.DB.search(self.QUERY.type == 'app_data')
        if result and 'pinwheel_min_price' in result[0]:
            return result[0]['pinwheel_min_price']
    except Exception:
        pass
    return 10_000_000  # Default: 1 XLM

def _start_pinwheel(self):
    """Start the Pinwheel daemon."""
    if not HAS_PINWHEEL:
        self.open_msg_dialog('hvym-pinwheel is not installed.\nInstall with: pip install hvym-pinwheel')
        return

    if not self.PINTHEON_ACTIVE:
        self.open_msg_dialog('Pintheon must be running before starting Pinwheel.\n'
                             'Pinwheel needs access to the Kubo IPFS node inside Pintheon.')
        return

    # Ensure wallet is selected
    if not self.PINWHEEL_WALLET:
        self._select_pinwheel_wallet()
        if not self.PINWHEEL_WALLET:
            return  # User cancelled

    # Get wallet secret
    secret = self._get_pinwheel_wallet_secret()
    if not secret:
        self.open_msg_dialog('Could not retrieve wallet secret key.')
        return

    # Build config
    contract_id = self._get_pinwheel_contract_id()
    factory_id = self._get_pinwheel_factory_id()

    if not contract_id:
        self.open_msg_dialog('No pin service contract ID configured.\n'
                             'Deploy or configure the hvym_pin_service contract first.')
        return

    config = build_pinner_config(
        keypair_secret=secret,
        network=self.PINTHEON_NETWORK,
        contract_id=contract_id,
        factory_contract_id=factory_id,
        mode=self.PINWHEEL_MODE,
        min_price=self._get_pinwheel_min_price(),
    )

    # Create and start worker
    self.pinwheel_worker = PinwheelWorker(config, parent=self)
    self.pinwheel_worker.started_signal.connect(self._on_pinwheel_started)
    self.pinwheel_worker.stopped_signal.connect(self._on_pinwheel_stopped)
    self.pinwheel_worker.error_signal.connect(self._on_pinwheel_error)
    self.pinwheel_worker.start()
    logging.info("Starting Pinwheel daemon")

def _stop_pinwheel(self):
    """Stop the Pinwheel daemon gracefully."""
    if self.pinwheel_worker and self.pinwheel_worker.is_running:
        self.pinwheel_worker.stop()
        self.pinwheel_worker.wait(10000)  # Wait up to 10 seconds
        logging.info("Pinwheel daemon stopped")

def _on_pinwheel_started(self):
    """Handle Pinwheel started signal."""
    self.PINWHEEL_ACTIVE = True
    self.pinwheel_status_action.setText("Status: Running")
    self.start_pinwheel_action.setVisible(False)
    self.stop_pinwheel_action.setVisible(True)
    self.pinwheel_info_menu.setEnabled(True)
    logging.info("Pinwheel started")

    # Start periodic dashboard refresh
    self._pinwheel_refresh_timer = QTimer(self)
    self._pinwheel_refresh_timer.timeout.connect(self._refresh_pinwheel_dashboard)
    self._pinwheel_refresh_timer.start(30000)  # Every 30 seconds

def _on_pinwheel_stopped(self):
    """Handle Pinwheel stopped signal."""
    self.PINWHEEL_ACTIVE = False
    self.pinwheel_status_action.setText("Status: Stopped")
    self.start_pinwheel_action.setVisible(True)
    self.stop_pinwheel_action.setVisible(False)
    self.pinwheel_info_menu.setEnabled(False)

    # Stop refresh timer
    if hasattr(self, '_pinwheel_refresh_timer'):
        self._pinwheel_refresh_timer.stop()

def _on_pinwheel_error(self, error: str):
    """Handle Pinwheel error signal."""
    self.PINWHEEL_ACTIVE = False
    self.pinwheel_status_action.setText("Status: Error")
    self.start_pinwheel_action.setVisible(True)
    self.stop_pinwheel_action.setVisible(False)
    self.pinwheel_info_menu.setEnabled(False)
    logging.error(f"Pinwheel error: {error}")
    QMessageBox.warning(self, "Pinwheel Error",
                        f"Pinwheel daemon error:\n{error}")

def _refresh_pinwheel_dashboard(self):
    """Fetch current Pinwheel state and update menu items."""
    if not self.pinwheel_worker or not self.pinwheel_worker.is_running:
        return

    dashboard = self.pinwheel_worker.get_dashboard_sync()
    if dashboard is None:
        return

    earnings = dashboard.get('earnings', {})
    total_xlm = earnings.get('total_earned_xlm', '0 XLM')
    claims = earnings.get('claims_count', 0)
    pins = dashboard.get('pins_active', 0)
    offers = dashboard.get('offers_seen', 0)

    self.pinwheel_earnings_action.setText(f"Earned: {total_xlm} ({claims} claims)")
    self.pinwheel_pins_action.setText(f"Active Pins: {pins}")
    self.pinwheel_offers_action.setText(f"Offers Seen: {offers}")
```

### 3e. Settings methods

```python
def _toggle_pinwheel_mode(self):
    """Toggle between auto and approve mode."""
    new_mode = 'approve' if self.PINWHEEL_MODE == 'auto' else 'auto'
    self.PINWHEEL_MODE = new_mode
    self.DB.update({'pinwheel_mode': new_mode}, self.QUERY.type == 'app_data')
    self.pinwheel_mode_action.setText(f"Mode: {new_mode}")

    # If running, update the daemon's mode in real-time
    if self.pinwheel_worker and self.pinwheel_worker.is_running:
        try:
            loop = self.pinwheel_worker._loop
            if loop:
                future = asyncio.run_coroutine_threadsafe(
                    self.pinwheel_worker.daemon.data_api.set_mode(new_mode), loop
                )
                future.result(timeout=5)
        except Exception as e:
            logging.warning(f"Failed to update Pinwheel mode: {e}")

def _select_pinwheel_wallet(self):
    """Show dialog to select which wallet Pinwheel uses."""
    if not HAS_WALLET_MANAGER:
        self.open_msg_dialog('Wallet Manager not available.')
        return

    wm = WalletManager()
    wallets = wm.list_wallets(network=self.PINTHEON_NETWORK)
    if not wallets:
        self.open_msg_dialog(f'No {self.PINTHEON_NETWORK} wallets found.\n'
                             'Create a wallet first via Wallet Management.')
        return

    labels = [f"{w.label} ({w.address[:8]}...{w.address[-4:]})" for w in wallets]
    choice, ok = QInputDialog.getItem(
        self, "Select Pinwheel Wallet",
        "Choose a wallet for the Pinwheel daemon:",
        labels, 0, False
    )
    if ok and choice:
        idx = labels.index(choice)
        selected = wallets[idx]
        self.PINWHEEL_WALLET = selected.address
        self.DB.update({'pinwheel_wallet': selected.address},
                       self.QUERY.type == 'app_data')

def _set_pinwheel_min_price(self):
    """Show dialog to set minimum offer price in XLM (stored as stroops)."""
    current_stroops = self._get_pinwheel_min_price()
    current_xlm = current_stroops / 10_000_000

    xlm_str, ok = QInputDialog.getText(
        self, "Pinwheel Min Price",
        f"Minimum offer price (XLM):\n"
        f"Current: {current_xlm:.7g} XLM",
        text=f"{current_xlm:.7g}",
    )
    if ok and xlm_str:
        try:
            xlm_val = float(xlm_str)
            if xlm_val < 0:
                self.open_msg_dialog('Price must be positive.')
                return
            stroops = int(xlm_val * 10_000_000)
            self.DB.update({'pinwheel_min_price': stroops}, self.QUERY.type == 'app_data')
        except ValueError:
            self.open_msg_dialog('Invalid number. Enter a value in XLM (e.g. 1.5).')

def _get_pinwheel_wallet_secret(self) -> str:
    """Retrieve the secret key for the selected Pinwheel wallet."""
    if not HAS_WALLET_MANAGER or not self.PINWHEEL_WALLET:
        return ''
    wm = WalletManager()
    wallet = wm.get_wallet(self.PINWHEEL_WALLET)
    if not wallet:
        return ''

    if wallet.encrypted:
        # Mainnet wallet — need password
        password, ok = QInputDialog.getText(
            self, "Wallet Password",
            f"Enter password for wallet {wallet.label}:",
            QLineEdit.Password
        )
        if not ok or not password:
            return ''
        try:
            return wm.decrypt_secret(wallet.secret_key, password)
        except Exception:
            self.open_msg_dialog('Invalid password.')
            return ''
    else:
        # Testnet wallet — plaintext secret
        return wallet.secret_key

def _get_pinwheel_contract_id(self) -> str:
    """Get the hvym_pin_service contract ID for current network."""
    # Check TinyDB first
    try:
        result = self.DB.search(self.QUERY.type == 'app_data')
        if result and 'pinwheel_contract_id' in result[0]:
            return result[0]['pinwheel_contract_id']
    except Exception:
        pass

    # Check DeploymentManager
    if HAS_SOROBAN:
        try:
            dm = DeploymentManager()
            deps = dm.get_deployments(network=self.PINTHEON_NETWORK)
            for d in deps:
                if 'pin_service' in d.get('contract_name', '') and d.get('status') == 'deployed':
                    return d['contract_id']
        except Exception:
            pass

    # Fallback: hardcoded testnet contract
    if self.PINTHEON_NETWORK == 'testnet':
        return 'CCEDYFIHUCJFITWEOT7BWUO2HBQQ72L244ZXQ4YNOC6FYRDN3MKDQFK7'
    return ''

def _get_pinwheel_factory_id(self) -> str:
    """Get the hvym_pin_service_factory contract ID."""
    if self.PINTHEON_NETWORK == 'testnet':
        return 'CACBN6G2EPPLAQORDB3LXN3SULGVYBAETFZTNYTNDQ77B7JFRIBT66V2'
    return ''
```

### 3f. Shutdown integration

Add to `_quit_application()`:

```python
def _quit_application(self):
    """Clean shutdown of the application."""
    # Stop Pinwheel daemon
    if HAS_PINWHEEL and self.pinwheel_worker:
        self._stop_pinwheel()

    # Stop API server
    if HAS_API_SERVER and self.api_server:
        self._stop_api_server()

    qApp.quit()
```

### 3g. Pintheon dependency — auto-stop Pinwheel when Pintheon stops

Pinwheel depends on Pintheon's Kubo node. If Pintheon is stopped, Pinwheel must stop too.

In `_stop_pintheon()`, add before the Docker stop:

```python
def _stop_pintheon(self, confirm=True):
    stop = True
    if confirm:
        stop = self.open_confirm_dialog('Stop Pintheon Gateway?')
    if stop:
        # Stop Pinwheel first (depends on Pintheon's Kubo)
        if HAS_PINWHEEL and self.PINWHEEL_ACTIVE:
            self._stop_pinwheel()

        if self._stop_pintheon_direct():
            self.PINTHEON_ACTIVE = False
            self._update_ui_on_pintheon_stopped()
        else:
            self.open_msg_dialog('Failed to stop Pintheon. Check logs for details.')
```

---

## Phase 4: Pinner Registration Flow

Before Pinwheel can collect pins, the pinner must be registered on-chain (`join_as_pinner`). This requires:
- A funded wallet (join fee + stake)
- Node ID (Kubo peer ID)
- Multiaddr (IPFS listen address)

### Auto-registration check

On Pinwheel start, before launching the daemon:

```python
def _ensure_pinwheel_registered(self, secret: str, contract_id: str) -> bool:
    """Check if the wallet is registered as a pinner. Offer to register if not."""
    import asyncio
    from hvym_pinner.stellar.queries import ContractQueries
    from stellar_sdk import Keypair

    kp = Keypair.from_secret(secret)
    passphrase = ("Test SDF Network ; September 2015" if self.PINTHEON_NETWORK == "testnet"
                  else "Public Global Stellar Network ; September 2015")
    rpc_url = ("https://soroban-testnet.stellar.org" if self.PINTHEON_NETWORK == "testnet"
               else "https://soroban.stellar.org")

    queries = ContractQueries(contract_id, rpc_url, passphrase)
    try:
        loop = asyncio.new_event_loop()
        pinner = loop.run_until_complete(queries.get_pinner(kp.public_key))

        if pinner is not None and pinner.active:
            return True  # Already registered

        # Not registered — ask user
        reply = QMessageBox.question(
            self, "Pinwheel Registration Required",
            "This wallet is not registered as a pinner on-chain.\n\n"
            "Registration requires a join fee + stake deposit.\n"
            "Would you like to register now?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            return self._register_pinwheel(secret, contract_id)
        return False
    finally:
        loop.run_until_complete(queries.close())
        loop.close()
```

### Registration dialog

```python
def _register_pinwheel(self, secret: str, contract_id: str) -> bool:
    """Register as a pinner on-chain. Shows progress dialog."""
    # Get Kubo peer ID from the running Pintheon/Kubo node
    import requests
    try:
        resp = requests.post("http://127.0.0.1:5001/api/v0/id", timeout=5)
        kubo_id = resp.json()
        node_id = kubo_id.get('ID', '')
        # Extract first multiaddr
        addrs = kubo_id.get('Addresses', [])
        multiaddr = addrs[0] if addrs else '/ip4/127.0.0.1/tcp/4001'
    except Exception:
        node_id = 'unknown'
        multiaddr = '/ip4/127.0.0.1/tcp/4001'

    # Submit join_as_pinner tx (runs in a LoadingWorker)
    import asyncio
    from stellar_sdk import Keypair
    from hvym_pinner.bindings.hvym_pin_service import ClientAsync

    kp = Keypair.from_secret(secret)
    passphrase = ("Test SDF Network ; September 2015" if self.PINTHEON_NETWORK == "testnet"
                  else "Public Global Stellar Network ; September 2015")
    rpc_url = ("https://soroban-testnet.stellar.org" if self.PINTHEON_NETWORK == "testnet"
               else "https://soroban.stellar.org")

    def _do_register():
        loop = asyncio.new_event_loop()
        try:
            client = ClientAsync(contract_id, rpc_url, passphrase)
            tx = loop.run_until_complete(client.join_as_pinner(
                caller=kp.public_key,
                node_id=node_id.encode('utf-8'),
                multiaddr=multiaddr.encode('utf-8'),
                min_price=self._get_pinwheel_min_price(),
                source=kp.public_key,
                signer=kp,
            ))
            loop.run_until_complete(tx.sign_and_submit())
            return True
        except Exception as e:
            raise e
        finally:
            loop.close()

    # Show loading window during registration
    loading_window, worker = self.threaded_animated_loading_window(
        'REGISTERING PINWHEEL', _do_register, self.LOADING_GIF
    )
    # Block until complete (worker emits finished)
    worker.wait()
    return not worker.error_occurred if hasattr(worker, 'error_occurred') else True
```

---

## Phase 5: TinyDB Schema Additions

New fields in the `app_data` document:

```json
{
    "type": "app_data",
    "pinwheel_wallet": "GABCDEF...",
    "pinwheel_mode": "auto",
    "pinwheel_min_price": 10000000,
    "pinwheel_contract_id": "",
    "pinwheel_auto_start": false,
    "pinwheel_hunter_enabled": false
}
```

---

## Phase 6: Auto-start (optional)

If `pinwheel_auto_start` is true in TinyDB, start Pinwheel automatically when Pintheon starts:

```python
def _update_ui_on_pintheon_started(self):
    # ... existing code ...

    # Auto-start Pinwheel if configured
    if HAS_PINWHEEL and self._should_auto_start_pinwheel():
        QTimer.singleShot(5000, self._start_pinwheel)  # 5s delay for Kubo startup
```

---

## Phase 7: Approve Mode UI

When Pinwheel runs in `approve` mode, offers queue up waiting for user approval. Metavinci should show a notification and provide a quick-approve mechanism.

### Tray notification

```python
def _check_pinwheel_approval_queue(self):
    """Check if there are offers waiting for approval."""
    if not self.pinwheel_worker or not self.pinwheel_worker.is_running:
        return
    dashboard = self.pinwheel_worker.get_dashboard_sync()
    if dashboard and dashboard.get('offers_awaiting_approval', 0) > 0:
        count = dashboard['offers_awaiting_approval']
        self.tray_icon.showMessage(
            "Pinwheel",
            f"{count} offer(s) awaiting approval",
            QSystemTrayIcon.Information,
            5000
        )
```

Add to the refresh timer alongside `_refresh_pinwheel_dashboard`.

### Quick-approve action

```python
self.pinwheel_approve_action = QAction("Approve All Pending", self)
self.pinwheel_approve_action.triggered.connect(self._approve_all_pinwheel_offers)
self.pinwheel_info_menu.addAction(self.pinwheel_approve_action)

def _approve_all_pinwheel_offers(self):
    """Approve all pending offers in the Pinwheel queue."""
    if not self.pinwheel_worker or not self.pinwheel_worker.is_running:
        return
    try:
        loop = self.pinwheel_worker._loop
        future = asyncio.run_coroutine_threadsafe(
            self.pinwheel_worker.daemon.data_api.approve_offers(
                # Get all awaiting slot IDs
                [o['slot_id'] for o in
                 (self.pinwheel_worker.get_dashboard_sync() or {})
                 .get('approval_queue', [])]
            ), loop
        )
        results = future.result(timeout=10)
        approved = sum(1 for r in results if r.success)
        self.tray_icon.showMessage("Pinwheel", f"Approved {approved} offer(s)",
                                   QSystemTrayIcon.Information, 3000)
    except Exception as e:
        logging.error(f"Failed to approve offers: {e}")
```

---

## Tray Menu Layout (Final)

```
System Tray Menu
├── Tools
│   ├── Installations
│   │   ├── Install Pintheon
│   │   ├── Install press
│   │   └── Update press
│   ├── Press
│   │   └── Run press
│   └── Pintheon testnet
│       ├── Start / Stop Pintheon
│       ├── Open Tunnel
│       ├── Settings
│       └── Interface
├── Pinwheel                       ← NEW
│   ├── Status: Running
│   ├── ─────────
│   ├── Start Pinwheel / Stop Pinwheel
│   ├── ─────────
│   ├── Mode: auto
│   ├── Settings
│   │   ├── Select Wallet...
│   │   └── Set Min Price...
│   └── Dashboard
│       ├── Earned: 1.5000000 XLM (3 claims)
│       ├── Active Pins: 5
│       ├── Offers Seen: 12
│       └── Approve All Pending
├── Metadata API
├── Wallet Management
└── Exit
```

---

## Phase 8: CID Hunter + Pintheon Pinned Files Endpoint

### The Problem

CID Hunter currently discovers CIDs **reactively** from on-chain events:

1. `on_pin_event()` — only tracks CIDs where `publisher == our_address`
2. `on_pinned_event()` — records which pinner claimed a slot we're already tracking

This has three gaps:
- **Cold start**: A fresh pinner daemon has no event history, so CID Hunter has nothing to verify
- **Missed events**: If the daemon was offline when events fired, those CIDs are never tracked
- **Scope limit**: Only tracks CIDs published by our own address, not the full network view from our Pintheon node

### The Solution: Pintheon `/api/pinned_files` Endpoint

Pintheon already stores comprehensive file metadata in its TinyDB `file_book` table. Adding an endpoint that returns all pinned files gives CID Hunter a **reliable, complete source of truth** that the pinner can poll on startup and periodically.

### Shared JSON Schema: `PinnedFile`

This schema is shared between the Pintheon endpoint (producer) and CID Hunter (consumer). Define it once, use it in both repos.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "PinnedFileList",
  "type": "object",
  "required": ["node_address", "peer_id", "gateway", "files"],
  "properties": {
    "node_address": {
      "type": "string",
      "description": "Pintheon node's Stellar public key (G...)"
    },
    "peer_id": {
      "type": "string",
      "description": "Kubo IPFS peer ID (12D3KooW... or Qm...)"
    },
    "gateway": {
      "type": "string",
      "description": "Public gateway URL for this node (e.g. https://mypintheon.art)"
    },
    "network": {
      "type": "string",
      "enum": ["testnet", "mainnet"],
      "description": "Stellar network this node operates on"
    },
    "generated_at": {
      "type": "string",
      "format": "date-time",
      "description": "ISO 8601 timestamp when this response was generated"
    },
    "files": {
      "type": "array",
      "items": { "$ref": "#/$defs/PinnedFile" }
    }
  },
  "$defs": {
    "PinnedFile": {
      "type": "object",
      "required": ["cid", "name", "size", "pinned", "slot_id", "pin_qty", "pins_remaining", "offer_price"],
      "properties": {
        "cid": {
          "type": "string",
          "description": "IPFS CID (Qm... or bafy...)"
        },
        "name": {
          "type": "string",
          "description": "Original filename"
        },
        "content_type": {
          "type": "string",
          "description": "MIME type (e.g. image/png, application/pdf)"
        },
        "size": {
          "type": "number",
          "description": "File size in bytes"
        },
        "pinned": {
          "type": "boolean",
          "description": "Whether an active pin request exists on-chain"
        },
        "slot_id": {
          "type": ["integer", "null"],
          "description": "On-chain pin slot ID (null if not pinned)"
        },
        "pin_qty": {
          "type": "integer",
          "description": "Number of pin copies requested"
        },
        "pins_remaining": {
          "type": "integer",
          "description": "Copies still unfulfilled"
        },
        "offer_price": {
          "type": "integer",
          "description": "Price per pin in stroops (divide by 10,000,000 for XLM)"
        },
        "encrypted": {
          "type": "boolean",
          "description": "Whether the content is encrypted"
        },
        "directory": {
          "type": "string",
          "description": "MFS directory path"
        },
        "contract_id": {
          "type": "string",
          "description": "File token contract ID (empty if not tokenized)"
        }
      }
    }
  }
}
```

### Example Response

```json
{
  "node_address": "GDNAG4KFFVF5HCSGRWZIXZNL2SR2KBGJSHW2A6FI6DZI62XF6IBLO4GD",
  "peer_id": "12D3KooWExample...",
  "gateway": "https://127.0.0.1:9998",
  "network": "testnet",
  "generated_at": "2026-02-06T18:30:00Z",
  "files": [
    {
      "cid": "QmW2WQi7j6c7UgJTarActp7tDNikE4B2qXtFCfLPdsgaTQ",
      "name": "gallery-cover.png",
      "content_type": "image/png",
      "size": 2457600,
      "pinned": true,
      "slot_id": 3,
      "pin_qty": 3,
      "pins_remaining": 1,
      "offer_price": 10000000,
      "encrypted": false,
      "directory": "/my-gallery",
      "contract_id": ""
    },
    {
      "cid": "QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG",
      "name": "portrait-series-01.jpg",
      "content_type": "image/jpeg",
      "size": 8912400,
      "pinned": true,
      "slot_id": 5,
      "pin_qty": 3,
      "pins_remaining": 3,
      "offer_price": 10000000,
      "encrypted": false,
      "directory": "/my-gallery",
      "contract_id": "CTOKEN..."
    }
  ]
}
```

### Pintheon Implementation (Flask side)

New route in Pintheon's Flask app. Requires macaroon auth (same as other API endpoints):

```python
@app.route('/api/pinned_files', methods=['GET'])
def api_pinned_files():
    """Return all files with active pin requests as JSON.

    Used by CID Hunter to discover which CIDs to verify.
    Requires a valid access token.
    """
    token = request.args.get('token') or request.headers.get('Authorization', '').replace('Bearer ', '')
    if not _verify_access_token(token):
        return jsonify({'error': 'unauthorized'}), 401

    files = PINTHEON.get_files()
    pinned = [f for f in files if f.get('Pinned', False)]

    return jsonify({
        'node_address': PINTHEON.address,
        'peer_id': PINTHEON.peer_id,
        'gateway': PINTHEON.gateway_url,
        'network': PINTHEON.network,
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'files': [
            {
                'cid': f['CID'],
                'name': f['Name'],
                'content_type': f.get('Type', ''),
                'size': f.get('Size', 0),
                'pinned': True,
                'slot_id': f.get('PinSlotId'),
                'pin_qty': f.get('PinQty', 0),
                'pins_remaining': f.get('PinsRemaining', 0),
                'offer_price': f.get('PinOfferPrice', 0),
                'encrypted': f.get('Encrypted', False),
                'directory': f.get('Directory', '/'),
                'contract_id': f.get('ContractID', ''),
            }
            for f in pinned
        ],
    })
```

### CID Hunter Integration (hvym_pinner side)

#### New: `PintheonClient` helper

Small httpx client that queries the local Pintheon `/api/pinned_files` endpoint:

```python
# src/hvym_pinner/pintheon/client.py

"""Client for the local Pintheon node API."""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

log = logging.getLogger(__name__)


@dataclass
class PintheonPinnedFile:
    """A pinned file as reported by the Pintheon node."""
    cid: str
    name: str
    content_type: str
    size: int
    slot_id: int | None
    pin_qty: int
    pins_remaining: int
    offer_price: int
    encrypted: bool
    directory: str
    contract_id: str


@dataclass
class PintheonFileList:
    """Response from /api/pinned_files."""
    node_address: str
    peer_id: str
    gateway: str
    network: str
    files: list[PintheonPinnedFile]


class PintheonClient:
    """Queries the local Pintheon node for pinned file inventory."""

    def __init__(
        self,
        base_url: str = "https://127.0.0.1:9998",
        access_token: str = "",
        verify_ssl: bool = False,  # Pintheon uses self-signed certs
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = access_token
        self._verify_ssl = verify_ssl

    async def get_pinned_files(self) -> PintheonFileList | None:
        """Fetch the list of pinned files from the local Pintheon node."""
        try:
            async with httpx.AsyncClient(verify=self._verify_ssl) as client:
                resp = await client.get(
                    f"{self._base_url}/api/pinned_files",
                    params={"token": self._token} if self._token else {},
                    timeout=10,
                )
                resp.raise_for_status()
                data = resp.json()

            files = [
                PintheonPinnedFile(
                    cid=f["cid"],
                    name=f.get("name", ""),
                    content_type=f.get("content_type", ""),
                    size=f.get("size", 0),
                    slot_id=f.get("slot_id"),
                    pin_qty=f.get("pin_qty", 0),
                    pins_remaining=f.get("pins_remaining", 0),
                    offer_price=f.get("offer_price", 0),
                    encrypted=f.get("encrypted", False),
                    directory=f.get("directory", "/"),
                    contract_id=f.get("contract_id", ""),
                )
                for f in data.get("files", [])
            ]

            return PintheonFileList(
                node_address=data.get("node_address", ""),
                peer_id=data.get("peer_id", ""),
                gateway=data.get("gateway", ""),
                network=data.get("network", ""),
                files=files,
            )
        except Exception as exc:
            log.warning("Failed to fetch pinned files from Pintheon: %s", exc)
            return None
```

#### Modified: `CIDHunterOrchestrator` — add `sync_from_pintheon()`

New method that reconciles the Pintheon file list with the tracker:

```python
async def sync_from_pintheon(self, pintheon_client: 'PintheonClient') -> int:
    """Sync tracked CIDs from the local Pintheon node.

    Queries /api/pinned_files, then for each file with an active pin
    request (pins_remaining > 0), ensures it's in our tracked_cids table.
    Also queries on-chain slot state to discover which pinners have claimed,
    and adds them to tracked_pins for verification.

    Returns the number of new CIDs added to tracking.
    """
    file_list = await pintheon_client.get_pinned_files()
    if file_list is None:
        log.warning("Pintheon sync failed — no response")
        return 0

    added = 0
    for f in file_list.files:
        if f.slot_id is None or f.pins_remaining <= 0:
            continue  # No active pin request

        cid_hash = hashlib.sha256(f.cid.encode("utf-8")).hexdigest()

        # Ensure CID is tracked
        existing = await self._store.get_tracked_cid_by_slot(f.slot_id)
        if existing is None:
            await self._store.save_tracked_cid(
                cid=f.cid,
                cid_hash=cid_hash,
                slot_id=f.slot_id,
                publisher=file_list.node_address,
                gateway=file_list.gateway,
                pin_qty=f.pin_qty,
            )
            added += 1
            log.info("Synced CID %s (slot %d) from Pintheon", f.cid[:20], f.slot_id)

        # Check on-chain for existing claims → create TrackedPins
        slot_info = await self._queries.get_slot(f.slot_id)
        if slot_info is None:
            continue

        for claimer_addr in slot_info.claims:
            # Skip ourselves
            if claimer_addr == self._our_address:
                continue

            # Check if we already track this (CID, pinner) pair
            existing_pins = await self._store.get_tracked_pins(["tracking", "verified", "suspect"])
            already_tracked = any(
                p.cid == f.cid and p.pinner_address == claimer_addr
                for p in existing_pins
            )
            if already_tracked:
                continue

            pinner_info = await self._registry.get_pinner_info(claimer_addr)
            if pinner_info is None:
                continue

            now = datetime.now(timezone.utc).isoformat()
            pin = TrackedPin(
                cid=f.cid,
                cid_hash=cid_hash,
                pinner_address=claimer_addr,
                pinner_node_id=pinner_info.node_id,
                pinner_multiaddr=pinner_info.multiaddr,
                slot_id=f.slot_id,
                claimed_at=now,
            )
            await self._store.save_tracked_pin(pin)
            log.info(
                "Synced pinner %s for CID %s from on-chain claims",
                claimer_addr[:16], f.cid[:20],
            )

    log.info("Pintheon sync complete: %d new CIDs tracked", added)
    return added
```

#### Modified: `_scheduler_loop` — sync on startup

```python
async def _scheduler_loop(self) -> None:
    """Background loop that runs verification cycles periodically."""
    # Sync from Pintheon on first cycle (bootstrap / cold start recovery)
    if self._pintheon_client:
        try:
            await self.sync_from_pintheon(self._pintheon_client)
        except Exception as exc:
            log.warning("Initial Pintheon sync failed: %s", exc)

    while self._running:
        try:
            await self._scheduler.run_cycle()
        except asyncio.CancelledError:
            break
        except Exception as exc:
            log.error("Verification cycle error: %s", exc, exc_info=True)

        # Periodic re-sync (every N cycles) to catch newly pinned files
        self._cycle_count += 1
        if self._pintheon_client and self._cycle_count % self._resync_every == 0:
            try:
                await self.sync_from_pintheon(self._pintheon_client)
            except Exception as exc:
                log.warning("Periodic Pintheon sync failed: %s", exc)

        try:
            await asyncio.sleep(self._config.cycle_interval)
        except asyncio.CancelledError:
            break
```

#### Config additions

```python
# In HunterConfig:
pintheon_url: str = "https://127.0.0.1:9998"  # Local Pintheon gateway
pintheon_token: str = ""  # Access token for API auth
resync_interval: int = 10  # Re-sync from Pintheon every N verification cycles
```

### Metavinci Wiring

When building the Pinwheel config, pass the Pintheon URL and an access token:

```python
config = build_pinner_config(
    keypair_secret=secret,
    network=self.PINTHEON_NETWORK,
    contract_id=contract_id,
    factory_contract_id=factory_id,
    mode=self.PINWHEEL_MODE,
    min_price=self._get_pinwheel_min_price(),
    hunter_enabled=True,                          # Enable CID Hunter
    pintheon_url=f"https://127.0.0.1:{self.PINTHEON_PORT}",
    pintheon_token=self._get_pintheon_access_token(),
)
```

The access token comes from Pintheon's token management. Metavinci can either:
1. Read it from Pintheon's TinyDB (`~/pintheon_data/enc_db.json`, `access_tokens` table)
2. Request one via the Pintheon API on first Pinwheel start, store it in Metavinci's TinyDB

### Data Flow Diagram

```
Pintheon Node (Docker)
  │
  │ TinyDB file_book:
  │   [{CID, Name, Size, Pinned, PinSlotId, PinsRemaining, ...}]
  │
  ├──GET /api/pinned_files ──────────────────────────────────────┐
  │                                                               │
  │  On-Chain (hvym-pin-service)                                  │
  │   PIN events ──→ PinnerDaemon._handle_pin_event()             │
  │   PINNED events → PinnerDaemon._handle_pinned_event()         │
  │         │                    │                                │
  │         └────────┬───────────┘                                │
  │                  ▼                                            ▼
  │        CIDHunterOrchestrator                          PintheonClient
  │         ├── on_pin_event()      (real-time)      get_pinned_files()
  │         ├── on_pinned_event()   (real-time)              │
  │         ├── sync_from_pintheon() ◄───────────────────────┘
  │         │     (bootstrap + periodic)
  │         ▼
  │   SQLite tracked_cids + tracked_pins
  │         │
  │         ▼
  │   PeriodicVerificationScheduler
  │         │ verify each (CID, pinner) via DHT/Bitswap
  │         ▼
  │   Pass → status = "verified"
  │   Fail → consecutive_failures++
  │         │ if >= threshold
  │         ▼
  │   SorobanFlagSubmitter.submit_flag()
  │         │
  │         ▼
  │   On-chain flag_pinner() tx → bounty earned
```

### Why Both Event-Based and Polling?

| Source | Strengths | Weaknesses |
|--------|-----------|------------|
| On-chain events (existing) | Real-time, authoritative, captures new claims instantly | Misses events during downtime, requires cursor state, no retroactive discovery |
| Pintheon `/api/pinned_files` (new) | Complete inventory, survives restarts, catches anything the event stream missed | Slight delay (poll interval), only covers our node's files, needs API auth |

They complement each other. Events give real-time tracking of new claims. The Pintheon poll provides the safety net — ensuring CID Hunter's tracking list stays complete even after restarts, cursor resets, or prolonged downtime.

### CID Hunter Menu Items (in Metavinci tray)

Extend the Pinwheel Dashboard submenu:

```python
# In _setup_pinwheel_menu, add to pinwheel_info_menu:
self.pinwheel_hunter_action = QAction("Hunter: --", self)
self.pinwheel_hunter_action.setEnabled(False)
self.pinwheel_info_menu.addAction(self.pinwheel_hunter_action)

self.pinwheel_suspects_action = QAction("Suspects: --", self)
self.pinwheel_suspects_action.setEnabled(False)
self.pinwheel_info_menu.addAction(self.pinwheel_suspects_action)

self.pinwheel_bounties_action = QAction("Bounties: --", self)
self.pinwheel_bounties_action.setEnabled(False)
self.pinwheel_info_menu.addAction(self.pinwheel_bounties_action)
```

Update in `_refresh_pinwheel_dashboard`:

```python
hunter = dashboard.get('hunter')
if hunter:
    tracked = hunter.get('total_tracked_pins', 0)
    verified = hunter.get('verified_count', 0)
    suspect = hunter.get('suspect_count', 0)
    flagged = hunter.get('flagged_count', 0)
    bounties_xlm = hunter.get('bounties_earned_xlm', '0 XLM')

    self.pinwheel_hunter_action.setText(
        f"Hunter: {tracked} tracked, {verified} verified"
    )
    self.pinwheel_suspects_action.setText(
        f"Suspects: {suspect} suspect, {flagged} flagged"
    )
    self.pinwheel_bounties_action.setText(
        f"Bounties Earned: {bounties_xlm}"
    )
```

---

## File Summary

| File | Location | Action |
|------|----------|--------|
| `pinwheel_worker.py` | `/metavinci/pinwheel_worker.py` | CREATE — QThread worker + config builder |
| `metavinci.py` | `/metavinci/metavinci.py` | MODIFY — import, init, menu, lifecycle, settings, shutdown |
| `requirements.txt` | `/metavinci/requirements.txt` | MODIFY — add `hvym-pinwheel>=0.1.0` |
| `client.py` | `/hvym_pinner/src/hvym_pinner/pintheon/client.py` | CREATE — PintheonClient for `/api/pinned_files` |
| `__init__.py` | `/hvym_pinner/src/hvym_pinner/pintheon/__init__.py` | CREATE — package init |
| `orchestrator.py` | `/hvym_pinner/src/hvym_pinner/hunter/orchestrator.py` | MODIFY — add `sync_from_pintheon()`, startup sync, periodic re-sync |
| `config.py` | `/hvym_pinner/src/hvym_pinner/models/config.py` | MODIFY — add Pintheon fields to `HunterConfig` |
| Flask routes | `/pintheon/` (Pintheon repo) | MODIFY — add `GET /api/pinned_files` endpoint |

---

## Dependency Chain

```
Metavinci starts
  → User clicks "Start Pintheon"
    → Docker container starts (Kubo + Flask gateway)
      → User clicks "Start Pinwheel"
        → Wallet selected, secret retrieved
        → Registration checked (join_as_pinner if needed)
        → PinwheelWorker thread starts
          → PinnerDaemon.start() runs in async loop
            → CID Hunter syncs from Pintheon /api/pinned_files (bootstrap)
            → Polls Soroban events (real-time tracking)
            → Pins content via Kubo @ localhost:5001
            → Claims on-chain
            → CID Hunter verifies other pinners (periodic cycles)
            → Flags non-compliant pinners → earns bounties
            → DataAggregator serves dashboard + hunter stats to menu

Metavinci quits
  → _quit_application()
    → _stop_pinwheel() → daemon.stop() → thread.wait()
    → _stop_api_server() → server.stop() → thread.wait()
    → qApp.quit()
```

---

## Testing

### Unit tests (mock everything)
- `PinwheelWorker` starts/stops correctly
- Config builder produces valid `DaemonConfig`
- Signal emission on start/stop/error
- `PintheonClient` parses `/api/pinned_files` response correctly
- `sync_from_pintheon()` adds new CIDs and tracked pins

### Integration tests (require Kubo + testnet)
- Re-use Tier 4 E2E tests from `hvym_pinner` to validate the pipeline
- Add Metavinci-specific test: start worker, inject event, verify dashboard update
- Test `/api/pinned_files` endpoint against a real Pintheon container
- Test `sync_from_pintheon()` round-trip: Pintheon has files → hunter picks them up

### Manual testing checklist
- [ ] Start Pintheon → Start Pinwheel → verify menu shows "Running"
- [ ] Dashboard updates every 30s with real earnings/pins/offers
- [ ] Stop Pintheon → Pinwheel auto-stops
- [ ] Mode toggle: auto ↔ approve while running
- [ ] Wallet selection dialog lists correct network wallets
- [ ] Min price dialog accepts and persists value
- [ ] Mainnet wallet prompts for password
- [ ] Exit Metavinci cleanly shuts down Pinwheel
- [ ] Pinwheel start fails gracefully if not registered (offers registration)
- [ ] Approve mode shows tray notification for pending offers
- [ ] CID Hunter: tracked/verified/suspect counts appear in Dashboard menu
- [ ] CID Hunter: bounties earned displayed after flagging
- [ ] CID Hunter: sync from Pintheon on startup populates tracking list
- [ ] CID Hunter: files pinned in Pintheon appear in hunter tracking within one cycle
