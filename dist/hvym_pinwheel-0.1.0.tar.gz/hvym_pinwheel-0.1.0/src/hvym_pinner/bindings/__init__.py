"""Auto-generated Soroban contract bindings copied from pintheon_contracts."""
