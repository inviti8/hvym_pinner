"""hvym_pinner - Autonomous IPFS pinning daemon for the Heavymeta/Pintheon ecosystem."""

__version__ = "0.1.0"
